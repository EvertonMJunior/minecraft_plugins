package net.goodcraft.skywars.comandos;

import net.goodcraft.api.Comando;
import net.goodcraft.api.Message;
import net.goodcraft.api.Rank;
import net.goodcraft.api.Utils;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameState;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class TempoCmd extends Comando {

    public TempoCmd() {
        super("tempo", Rank.MODPLUS);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length != 1) {
            Message.ERROR.send(sender, "Use /tempo <tempo>");
            return false;
        }
        try {
            int time = Integer.valueOf(args[0]);

            if (Main.estado == GameState.PREGAME) {
                Main.toStart = time;
            } else {
                Main.gameTime = time;
            }
            Message.INFO.send(sender, "Tempo de jogo alterado para " + Utils.secondsToSentence(time) + ".");

        } catch (Exception e) {
            Message.ERROR.send(sender, "Use /tempo <tempo>");
        }

        return false;
    }

}
