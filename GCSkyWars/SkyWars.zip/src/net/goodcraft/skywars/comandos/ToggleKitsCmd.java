package net.goodcraft.skywars.comandos;

import net.goodcraft.api.*;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.kits.Kit;
import net.goodcraft.skywars.kits.KitManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class ToggleKitsCmd extends Comando {

    public ToggleKitsCmd() {
        super("togglekits", Rank.MODPLUS);
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            if (Main.toggleKits) {
                for (Kit k : Kit.kits) {
                    k.getPlayers().clear();
                }
                Title.INFO.broadcast("SkyWars", "Os kits foram desativados!");
                Main.toggleKits = false;
                return false;
            }
            Title.INFO.broadcast("SkyWars", "Os kits foram ativados!");
            Main.toggleKits = true;
            return false;
        }
        Kit kit = KitManager.getKitByString(Utils.getSentence(args));
        if (kit == null) {
            Message.ERROR.send(sender, "Este kit não existe!");
            return false;
        }
        if (!Main.notToggled.contains(kit)) {
            Main.notToggled.add(kit);
            kit.getPlayers().forEach(kit::removePlayer);
            Title.INFO.broadcast("SkyWars", "O kit " + kit.toString() + " foi desativado!");
            return false;
        }
        Title.INFO.broadcast("SkyWars", "O kit " + kit.toString() + " foi ativado!");
        Main.notToggled.remove(kit);
        return false;
    }
}