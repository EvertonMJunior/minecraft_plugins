package net.goodcraft.skywars.comandos;

import net.goodcraft.api.Comando;
import net.goodcraft.api.Message;
import net.goodcraft.api.Rank;
import net.goodcraft.api.Utils;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameState;
import net.goodcraft.skywars.kits.Kit;
import net.goodcraft.skywars.kits.KitManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class SetKitCmd extends Comando {

    public SetKitCmd() {
        super("setkit", Rank.MODPLUS);
        setGetPlayerByName(0);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length != 2) {
            Message.ERROR.send(sender, "Use /setkit <player> <kit>");
            return false;
        }
        Kit k = KitManager.getKitByString(Utils.getSentence(args, 1));
        if (k == null) {
            Message.ERROR.send(sender, "O kit " + args[1] + " não foi encontrado.");
            return false;
        }
        for (Kit kk : Kit.kits) {
            if(!kk.getPlayers().contains(player)){
                continue;
            }
            kk.removePlayer(player);
        }
        k.addPlayer(player);

        if (Main.estado != GameState.PREGAME) {
            if (k.getItems() != null) {
                for (ItemStack items : k.getItems()) {
                    if (items == null) {
                        continue;
                    }
                    player.getInventory().addItem(items);
                }
            }
        }
        Message.INFO.send(sender, "Agora " + player.getName() + " está usando o kit " + k.toString() + ".");

        return false;
    }

}