package net.goodcraft.skywars.comandos;

import net.goodcraft.api.Comando;
import net.goodcraft.api.Rank;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameManager;
import net.goodcraft.skywars.game.GameState;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class StartCmd extends Comando {

    public StartCmd() {
        super("start", Rank.MODPLUS);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (Main.estado == GameState.PREGAME) {
            GameManager.start();
        } else if(Main.estado == GameState.INVENCIBILITY){
            Main.gameTime = 10;
        }
        return false;
    }

}