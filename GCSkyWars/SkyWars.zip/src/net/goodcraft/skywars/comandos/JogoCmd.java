package net.goodcraft.skywars.comandos;

import net.goodcraft.api.Comando;
import net.goodcraft.api.Utils;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameManager;
import net.goodcraft.skywars.game.GameState;
import net.goodcraft.skywars.kits.KitManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class JogoCmd extends Comando {

    public JogoCmd() {
        super("jogo", new String[]{"game", "help"});
        setInGameOnly(true);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String kit = "Nenhum";
        if (KitManager.hasAnyKit(p)) {
            kit = KitManager.getKit(p).toString();
        }
        GameState gs = Main.estado;

        p.sendMessage(" ");
        p.sendMessage("§6           SkyWars");

        p.sendMessage(" ");
        p.sendMessage(" §fSeu kit §b➛ §7" + kit);

        if (gs != GameState.PREGAME) p.sendMessage(" §fKills §b➛ §7" + GameManager.getKills(p));

        if (gs == GameState.INVENCIBILITY)
            p.sendMessage(" §fInvencibilidade  §b➛ §7" + Utils.secondsToString(120 - Main.gameTime));

        if (gs != GameState.INVENCIBILITY && gs != GameState.PREGAME)
            p.sendMessage(" §fTempo  §b➛ §7" + Utils.secondsToString(Main.gameTime));

        if (gs == GameState.PREGAME) p.sendMessage(" §fIniciando  §b➛ §7" + Utils.secondsToString(Main.toStart));

        p.sendMessage(" ");
        p.sendMessage("   §6www.good-craft.net");
        p.sendMessage(" ");

        return false;
    }

}
