package net.goodcraft.skywars.kits;

import com.google.gson.reflect.TypeToken;
import net.goodcraft.Main;
import net.goodcraft.api.json.JSONUtils;
import net.goodcraft.sql.MySQL;
import org.bukkit.scheduler.BukkitRunnable;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;

public class KitAPI {
    @SuppressWarnings("unchecked")
    public static ArrayList<Kit> getKits(UUID id) {
        if (!MySQL.ativo) {
            return new ArrayList<Kit>();
        }
        try {
            PreparedStatement ps = Main.getSQL().getConnection()
                    .prepareStatement("SELECT kits FROM good_skywars WHERE uuid='" + id + "'");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String json = rs.getString("kits");
                if (json.isEmpty()) {
                    return new ArrayList<Kit>();
                }
                ArrayList<Kit> kits = new ArrayList<>();
                ArrayList<String> kitNames = (ArrayList<String>) JSONUtils.fromJson(json,
                        new TypeToken<ArrayList<String>>() {
                        }.getType());

                for (String kit : kitNames) {
                    Kit k = KitManager.getKitByString(kit);
                    if (k == null) continue;
                    kits.add(k);
                }

                Main.getSQL().closeResources(rs, ps);
                return kits;
            }
            rs.close();
            ps.close();
        } catch (SQLException e1) {
            e1.printStackTrace();
            try {
                if (!Main.getSQL().hasConnection()) Main.getSQL().openConnection();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return new ArrayList<Kit>();
    }

    public static boolean hasKit(UUID id, Kit kit) {
        return getKits(id).contains(kit);
    }

    public static boolean addKit(UUID id, Kit kit) {
        if (!MySQL.ativo) {
            return false;
        }
        final ArrayList<String> kits = new ArrayList<>();
        for(Kit k : getKits(id)){
            kits.add(k.toString());
        }
        kits.add(kit.toString());

        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    PreparedStatement ps = Main.getSQL().getConnection()
                            .prepareStatement("UPDATE good_skywars SET kits='" +
                                    JSONUtils.toJson(kits) +
                                    "' WHERE uuid='" +
                                    id +
                                    "';");
                    ps.executeUpdate();
                    ps.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                    try {
                        if (!Main.getSQL().hasConnection()) Main.getSQL().openConnection();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }.runTaskLaterAsynchronously(Main.getPlugin(), 5L);
        return true;
    }
}
