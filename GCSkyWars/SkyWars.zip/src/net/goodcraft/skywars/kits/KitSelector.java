package net.goodcraft.skywars.kits;

import net.goodcraft.api.Item;
import net.goodcraft.api.Message;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.eventos.JoinEvent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;

public class KitSelector implements Listener {

    public static void openInv(Player p) {
        ArrayList<Kit> pKits = KitAPI.getKits(p.getUniqueId());
        if (pKits.isEmpty() && Main.freeKits.get().isEmpty()) {
            Message.ERROR.send(p, "Você não tem kits!");
            return;
        }

        Inventory inv = Bukkit.createInventory(p, 36, "Kits");
        inv.clear();
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, Item.item(Material.STAINED_GLASS_PANE, 1, " ", 1));
        }
        for (int i = 27; i < 36; i++) {
            inv.setItem(i, Item.item(Material.STAINED_GLASS_PANE, 1, " ", 1));
        }
        for (Kit kit : Kit.kits) {
            if (!Main.freeKits.get().contains(kit) && !pKits.contains(kit)) continue;
            inv.addItem(kit.getKitSelectorItem());
        }

        p.openInventory(inv);
    }

    @EventHandler
    public void click(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        Inventory inv = e.getInventory();
        if (inv != null) {
            if (inv.getName().equalsIgnoreCase("Kits")) {
                ItemStack item = e.getCurrentItem();
                if (item != null) {
                    e.setCancelled(true);
                    for (Kit k : Kit.kits) {
                        if (item.hasItemMeta()) {
                            if (item.getItemMeta().hasDisplayName()) {
                                if (item.getItemMeta().getDisplayName().contains(k.toString())) {
                                    p.chat("/kit " + k.toString());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player p = e.getPlayer();
        if (e.getItem() != null && e.getAction().name().contains("RIGHT")) {
            if (e.getItem().equals(JoinEvent.kitsChest)) {
                e.setCancelled(true);
                e.setUseInteractedBlock(Event.Result.DENY);
                KitSelector.openInv(e.getPlayer());
            } else if (e.getItem().equals(JoinEvent.shopChest)) {
                e.setCancelled(true);
                e.setUseInteractedBlock(Event.Result.DENY);
                ShopManager.open(p);
            }
        }
    }

}
