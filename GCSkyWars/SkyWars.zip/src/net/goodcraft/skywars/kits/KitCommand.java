package net.goodcraft.skywars.kits;

import net.goodcraft.api.*;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameState;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class KitCommand extends Comando {

    public KitCommand() {
        super("kit");
        setInGameOnly(true);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!Main.toggleKits) {
            Message.ERROR.send(p, "Os kits estão desativados.");
            p.closeInventory();
            return true;
        }
        if (args.length == 0) {
            if(Main.estado == GameState.PREGAME){
                KitSelector.openInv(p);
            } else {
                Message.ERROR.send(p, "O jogo já iniciou!");
            }
            return false;
        }
        Kit k = KitManager.getKitByString(Utils.getSentence(args));
        if (k != null) {
            if (Main.freeKits.isFree(k) || KitAPI.hasKit(p.getUniqueId(), k)) {
                if (Main.estado == GameState.PREGAME) {
                    if (Main.notToggled.contains(k)) {
                        Message.ERROR.send(p, "Este kit está desativado no momento!");
                        p.closeInventory();
                        return false;
                    }
                    if(k.isVip() && !Rank.has(p.getUniqueId(), Rank.BRONZE)){
                        Message.ERROR.send(p, "Você precisa de um VIP para poder usar este kit! Adquira um em loja.good-craft.net!");
                        p.closeInventory();
                        return false;
                    }
                    KitManager.removeKit(p);
                    k.addPlayer(p);
                    p.sendMessage(" ");
                    Title.INFO.send(p, k.toString(), "Kit selecionado!");

                    String s = "";
                    for (String ss : k.getDesc()) {
                        s = s + " " + ss;
                    }
                    Message.INFO.send(p, "Você escolheu o kit " + k.toString() + ".");
                    Message.INFO.send(p, "Descrição: " + s);

                    p.playSound(p.getLocation(), Sound.NOTE_PIANO, 1.0F, 1.0F);
                    p.closeInventory();
                } else {
                    Message.ERROR.send(p, "O jogo já iniciou!");
                }
            } else {
                Message.ERROR.send(p, "Você não tem este kit, compre-o em loja.good-craft.net!");
            }
        } else {
            Message.ERROR.send(p, "O kit " + args[0] + " não foi encontrado!");
            Message.ERROR.send(p, "Use /kit para selecionar um kit.");
        }
        return false;
    }

}
