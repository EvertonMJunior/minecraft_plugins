package net.goodcraft.skywars.kits.habilidades;

import net.goodcraft.api.Item;
import net.goodcraft.skywars.kits.Kit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.EnchantingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.material.Dye;

import java.util.Arrays;

public class Enchanter extends Kit {
    public Enchanter() {
        super("Enchanter", Material.ENCHANTMENT_TABLE,
                new ItemStack[]{Item.item(Material.ENCHANTMENT_TABLE),
                        Item.item(Material.EXP_BOTTLE, 3)}, Arrays.asList(
                        "§7Ganhe um Altar de Encantamentos",
                        "§7e 3 frascos de XP. Fique muito",
                        "§7mais forte que seus oponentes!"
                ));
        setPrice(1500);
    }

    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent e) {
        if (e.getInventory() instanceof EnchantingInventory) {
            EnchantingInventory inv = (EnchantingInventory) e.getInventory();
            Dye d = new Dye();
            d.setColor(DyeColor.BLUE);
            ItemStack i = d.toItemStack();
            i.setAmount(20);
            inv.setItem(1, i);
        }
    }

    @EventHandler
    public void onInvClick(InventoryClickEvent e){
        if (e.getInventory() instanceof EnchantingInventory) {
            if(e.getSlot() == 1){
                e.setCancelled(true);
                e.setResult(Event.Result.DENY);
            }
        }
    }
}
