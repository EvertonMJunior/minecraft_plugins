package net.goodcraft.skywars.eventos;

import net.goodcraft.api.AdminAPI;
import net.goodcraft.api.AdminEvent;
import net.goodcraft.api.Utils;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameState;
import net.goodcraft.skywars.game.SpectatorManager;
import net.goodcraft.skywars.kits.KitManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

import java.util.ArrayList;
import java.util.UUID;

public class GeneralEvents implements Listener {
    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (Main.estado == GameState.PREGAME || Main.estado == GameState.INVENCIBILITY) {
            e.setCancelled(true);
        }
        if(SpectatorManager.spectators.containsKey(e.getEntity().getUniqueId())){
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void click(InventoryClickEvent e) {
        if (e.getWhoClicked().getGameMode() == GameMode.CREATIVE) return;
        if (Main.estado == GameState.PREGAME) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void spawn(EntitySpawnEvent e) {
        ArrayList<EntityType> allowedEnt = new ArrayList<>();
        allowedEnt.add(EntityType.ARMOR_STAND);
        allowedEnt.add(EntityType.DROPPED_ITEM);
        allowedEnt.add(EntityType.PLAYER);

        if (allowedEnt.contains(e.getEntityType())) {
            return;
        }
        if (Main.estado == GameState.PREGAME) {
            e.setCancelled(true);
        }
    }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void drop(PlayerDropItemEvent e) {
        if(e.getItemDrop().getItemStack().getType() == Material.INK_SACK &&
                e.getItemDrop().getItemStack().getData().getData() == (byte)4){
            e.getItemDrop().remove();
            return;
        }

        if (Main.estado == GameState.PREGAME) {
            e.setCancelled(true);
        } else if (SpectatorManager.spectators.containsKey(e.getPlayer().getUniqueId())){
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void pickup(PlayerPickupItemEvent e) {
        if (Main.estado == GameState.PREGAME) {
            e.setCancelled(true);
        } else if (AdminAPI.admins.containsKey(e.getPlayer().getName())) {
            e.setCancelled(true);
        } else if (SpectatorManager.spectators.containsKey(e.getPlayer().getUniqueId())){
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e){
        for(UUID id : SpectatorManager.spectators.keySet()){
            Player sp = Bukkit.getPlayer(id);
            if(sp == null) continue;
            if(e.getBlockPlaced().getLocation().distance(sp.getLocation()) <= 2){
                sp.teleport(sp.getLocation().clone().add(0, 2, 0));
            }
        }

        if(e.getBlockPlaced().getLocation().getY() >= Main.lobbyY + 5){
            e.setCancelled(true);
            e.setBuild(false);
        }
    }

    @EventHandler
    public void onBucket(PlayerBucketEmptyEvent e){
        if(e.getBlockClicked().getLocation().getY() >= Main.lobbyY + 8){
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onAdmin(AdminEvent e) {
        Player p = e.getPlayer();
        if (e.isEntering()) {
            if(Main.players.contains(p.getUniqueId())){
                Main.players.remove(p.getUniqueId());
                if (Main.estado != GameState.PREGAME) {
                    String kit = "Nenhum";
                    if (KitManager.hasAnyKit(p)) kit = KitManager.getKit(p).toString();
                    Utils.broadcast("§6[SkyWars] §e" + p.getName() + "§7(" + kit + ")§e morreu!");
                    KitManager.removeKit(p);
                }
            }
        } else {
            if (Main.estado == GameState.PREGAME) Main.players.add(p.getUniqueId());
        }
    }
}
