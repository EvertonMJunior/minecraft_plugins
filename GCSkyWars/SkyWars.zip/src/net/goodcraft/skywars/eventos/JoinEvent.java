package net.goodcraft.skywars.eventos;

import net.goodcraft.api.Item;
import net.goodcraft.api.Rank;
import net.goodcraft.api.Title;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameState;
import net.goodcraft.skywars.game.SpectatorManager;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.inventory.ItemStack;

public class JoinEvent implements Listener{

    public static ItemStack kitsChest = Item.item(Material.CHEST, 1, "§a§lKits §7(Clique Direito)");
    public static ItemStack shopChest = Item.item(Material.ENDER_CHEST, 1, "§c§lLoja §7(Clique Direito)");

    public static void setInitialItems(Player p) {
        p.getInventory().clear();
        p.getInventory().setItem(2, kitsChest);
        p.getInventory().setItem(6, shopChest);

        p.getInventory().setHeldItemSlot(2);
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent e) {
        Player p = e.getPlayer();
        Rank pRank = Rank.getPlayerRank(p.getUniqueId());
        if (Main.players.size() >= Main.maxPlayers) {
            if (!Rank.has(pRank, Rank.BRONZE)) {
                e.setKickMessage("§eO servidor já está cheio! \n§eCompre VIP para isso não acontecer de novo: \n§lloja.good-craft.net");
            }
        } else if (Main.estado == null) {
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER, "§cAguarde...");
        } else if (Main.estado != GameState.PREGAME) {
            if (Main.gameTime < 300) {
                if (!Rank.has(pRank, Rank.BRONZE)) {
                    e.disallow(PlayerLoginEvent.Result.KICK_OTHER, "§eO jogo já iniciou! \n§eCompre VIP para isso não acontecer de novo: \n§lloja.good-craft.net");
                }
            } else {
                if (!Rank.has(pRank, Rank.BRONZE)) {
                    e.disallow(PlayerLoginEvent.Result.KICK_OTHER, "§eO jogo já iniciou! \n§eCompre VIP para poder espectar partidas: \n§lloja.good-craft.net");
                }
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e){
        Player p = e.getPlayer();
        setInitialItems(p);

        p.teleport(Main.usingWorld.getSpawnLocation().clone().add(0.5, 0, 0.5));

        e.setJoinMessage(null);
        p.setWalkSpeed(0.2f);

        p.setHealth(20.0D);
        p.setFoodLevel(20);
        Title.INFO.send(p, "SkyWars", "Seja o melhor dos jogadores!");
        if (Main.estado == GameState.PREGAME) {
            p.setGameMode(GameMode.ADVENTURE);
            if (!Main.players.contains(p.getUniqueId())) {
                Main.players.add(p.getUniqueId());
            }
        } else {
                if (Main.gameTime >= 300) {
                    SpectatorManager.put(p);
                } else {
                    if (!Main.players.contains(p.getUniqueId())) {
                        Main.players.add(p.getUniqueId());
                    }
                    p.setGameMode(GameMode.SURVIVAL);
                    p.getInventory().addItem(new ItemStack(Material.COMPASS));
                }
        }

    }
}
