package net.goodcraft.skywars.eventos;

import net.goodcraft.GameMode;
import net.goodcraft.api.SecondsEvent;
import net.goodcraft.api.Utils;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameManager;
import net.goodcraft.skywars.game.SpectatorManager;
import net.goodcraft.skywars.kits.KitManager;
import net.goodcraft.sql.SQLStatus;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;
import java.util.UUID;

public class DeathEvent implements Listener {
    public static void broadcastDeath(final Player p, String msg) {
        String message;
        if (!KitManager.hasAnyKit(p)) {
            message = p.getName() + "§7(Nenhum)§e ";
        } else {
            message = p.getName() + "§7(" + KitManager.getKit(p).toString() + ")§e ";

        }
        Utils.broadcast("§6[SkyWars]§e " + message + msg + "§e!");
        KitManager.removeKit(p);


        new BukkitRunnable() {
            public void run() {
                if (!p.isOnline()) return;
                SpectatorManager.put(p);
                p.setHealth(20D);
            }
        }.runTask(Main.getPlugin());
    }

    @EventHandler
    public void death(PlayerDeathEvent e) {
        final Player p = e.getEntity();
        e.setDeathMessage(null);
        DamageEvent.combatLog.remove(p.getUniqueId());
        if (Main.players.contains(p.getUniqueId())) {
            Main.players.remove(p.getUniqueId());
            SQLStatus.addStatus(p.getUniqueId(), GameMode.SKYWARS, "deaths", 1);
            SQLStatus.addStatus(p.getUniqueId(), GameMode.SKYWARS, "perdas", 1);
            GameManager.kills.remove(p.getUniqueId());

            EntityDamageEvent cause2 = p.getLastDamageCause();
            EntityDamageEvent.DamageCause cause = cause2.getCause();
            if (cause == EntityDamageEvent.DamageCause.FALL) {
                String msg = doubleMsg("nunca ouviu falar em escadas",
                        "caiu de um lugar alto");
                broadcastDeath(p, msg);
            } else if (cause == EntityDamageEvent.DamageCause.CONTACT) {
                String msg = doubleMsg("morreu por um cacto",
                        "morreu por um cacto");
                broadcastDeath(p, msg);
            } else if (cause == EntityDamageEvent.DamageCause.DROWNING) {
                String msg = doubleMsg("morreu afogado",
                        "morreu afogado");
                broadcastDeath(p, msg);
            } else if (cause == EntityDamageEvent.DamageCause.LAVA) {
                String msg = doubleMsg("tentou nadar na lava",
                        "estava brincando muito perto da lava");
                broadcastDeath(p, msg);
            } else if (cause == EntityDamageEvent.DamageCause.SUFFOCATION) {
                broadcastDeath(p, "morreu sufocado");
            } else if (cause == EntityDamageEvent.DamageCause.FIRE) {
                broadcastDeath(p, "tostou como uma carne assada");
            } else if (cause == EntityDamageEvent.DamageCause.POISON) {
                broadcastDeath(p, "morreu envenenado");
            } else if (cause == EntityDamageEvent.DamageCause.FIRE_TICK) {
                broadcastDeath(p, "queimado");
            } else if (cause == EntityDamageEvent.DamageCause.LIGHTNING) {
                broadcastDeath(p, "morreu por raios");
            } else if (cause == EntityDamageEvent.DamageCause.STARVATION) {
                broadcastDeath(p, "morreu de fome");
            } else if (cause == EntityDamageEvent.DamageCause.WITHER) {
                broadcastDeath(p, "morreu em envenenado");
            } else if (cause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
                broadcastDeath(p, "morreu explodido");
            } else if (cause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
                broadcastDeath(p, "morreu explodido");
            } else if (cause == EntityDamageEvent.DamageCause.CUSTOM) {
                broadcastDeath(p, "morreu pela borda do mundo");
            } else if (cause == EntityDamageEvent.DamageCause.VOID) {
                broadcastDeath(p, "caiu do mundo");
            } else if (cause2.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
                Entity entity = ((EntityDamageByEntityEvent) cause2)
                        .getDamager();
                if (entity.getType().equals(EntityType.PLAYER)) {
                    Player killer = (Player) entity;
                    GameManager.addKill(killer);
                    SQLStatus.addCoins(killer.getUniqueId(), 100);
                    String kill;
                    if (!KitManager.hasAnyKit(killer)) {
                        kill = killer.getName() + "§7(Nenhum)§e";
                    } else {
                        kill = killer.getName() + "§7(" + KitManager.getKit(killer).toString() + ")§e";

                    }
                    String id = killer.getItemInHand().getType().name();
                    broadcastDeath(p, "foi morto por " + kill);
                } else {
                    String msg = doubleMsg("morreu por um monstro",
                            "estava brincando com um monstro");
                    broadcastDeath(p, msg);
                }
            } else {
                broadcastDeath(p, "morreu!");
            }
        } else {
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (!p.isOnline()) return;
                    p.chat("/admin");
                    p.setHealth(20D);
                }
            }.runTask(Main.getPlugin());
        }
    }

    public String doubleMsg(String msg, String msg2) {
        if (new Random().nextBoolean()) {
            return msg;
        } else {
            return msg2;
        }
    }

    @EventHandler
    public void respawn(PlayerRespawnEvent e) {
        if (!Main.players.contains(e.getPlayer().getUniqueId())) {
            e.setRespawnLocation(e.getPlayer().getWorld().getSpawnLocation().clone().add(0.5, 0, 0.5));
            if (e.getPlayer().getAllowFlight()) {
                e.getPlayer().setFlying(true);
            }
        }
    }

    @EventHandler
    public void onVoidDeath(SecondsEvent e) {
        for (UUID id : Main.players) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (!(p.getLocation().getY() <= 0)) continue;

            broadcastDeath(p, "caiu do mundo");
            p.getInventory().clear();
            p.getInventory().setArmorContents(null);
            SpectatorManager.put(p);
            p.setHealth(p.getMaxHealth());
            p.teleport(p.getLocation().getWorld().getSpawnLocation().clone().add(0.5, 0, 0.5));
            Main.players.remove(p.getUniqueId());
        }
    }

}
