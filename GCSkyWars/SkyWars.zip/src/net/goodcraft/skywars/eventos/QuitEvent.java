package net.goodcraft.skywars.eventos;

import net.goodcraft.api.Message;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.game.GameState;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class QuitEvent implements Listener {
    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        event(e.getPlayer());
    }

    @EventHandler
    public void onKick(PlayerKickEvent e) {
        event(e.getPlayer());
    }

    private void event(Player p){
        if (Main.estado == GameState.PREGAME) {
            Main.players.remove(p.getUniqueId());
        }
        Main.getScoreboard().removeBoard(p);
        if(DamageEvent.combatLog.containsKey(p.getUniqueId())){
            Message.INFO.broadcast("§6[SkyWars]§e " + p.getName() + " deslogou em combate! (" + Main.players.size() + " jogadores)");
            if (p.isOnline()) {
                p.damage(p.getMaxHealth(), p);

                for (ItemStack item : p.getInventory().getContents()) {
                    if (item != null) {
                        if (p.getLocation() != null) {
                            p.getLocation().getWorld().dropItemNaturally(p.getLocation(), item);
                        }
                    }
                }

                for (ItemStack item : p.getInventory().getArmorContents()) {
                    if (item != null) {
                        if (p.getLocation() != null) {
                            p.getLocation().getWorld().dropItemNaturally(p.getLocation(), item);
                        }
                    }
                }
            }
            return;
        }
        if(Main.players.contains(p.getUniqueId())){
            Main.players.remove(p.getUniqueId());
            Message.INFO.broadcast("§6[SkyWars]§e " + p.getName() + " saiu da partida! (" + Main.players.size() + " jogadores)");
        }
    }
}
