package net.goodcraft.skywars.eventos;

import net.goodcraft.api.SecondsEvent;
import net.goodcraft.skywars.Main;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class MotdEvent implements Listener {
    @EventHandler
    public void onSecond(SecondsEvent e){
        ((CraftServer)Bukkit.getServer()).getServer().setMotd((Main.estado == null ? "REINICIANDO" : Main.estado) +
                ":" + Main.players.size() + ":" + Main.maxPlayers + ":" + Main.getPlugin().getConfig().getString("MAPA"));
    }
}
