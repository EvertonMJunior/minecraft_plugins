package net.goodcraft.skywars.game;

public enum GameState {
    PREGAME, INVENCIBILITY, STARTED, WIN;
}
