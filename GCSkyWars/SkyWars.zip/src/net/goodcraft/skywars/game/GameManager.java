package net.goodcraft.skywars.game;

import net.goodcraft.api.*;
import net.goodcraft.skywars.Main;
import net.goodcraft.skywars.kits.Kit;
import net.goodcraft.skywars.kits.KitManager;
import net.goodcraft.sql.SQLStatus;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.UUID;

public class GameManager {
    public static HashMap<UUID, Integer> kills = new HashMap<>();

    public static void start() {
        if (GameTimer.preGameTask != null) {
            GameTimer.preGameTask.cancel();
            GameTimer.preGameTask = null;
        }
        teleport();
        Main.editSession.undo(Main.editSession);

        Main.estado = GameState.INVENCIBILITY;

        Main.usingWorld.getEntities().stream().filter(en -> en instanceof Villager).forEach(Entity::remove);
        Main.usingWorld.getEntities().stream().filter(en -> en instanceof Item).forEach(Entity::remove);
        Main.usingWorld.getEntities().stream().filter(en -> en instanceof ArmorStand).forEach(Entity::remove);

        Kit.kits.forEach(Kit::onStartGame);

        Title.INFO.broadcast("SkyWars", "Boa sorte! :D");

        Main.usingWorld.setTime(0);
        Main.usingWorld.setThundering(false);
        Main.usingWorld.setStorm(false);

        for (UUID id : Main.players) {
            Player p = Bukkit.getPlayer(id);
            p.closeInventory();
            p.getInventory().clear();
            p.playSound(p.getLocation(), Sound.ANVIL_LAND, 10.0F, 1.0F);
            p.playSound(p.getLocation(), Sound.PISTON_EXTEND, 10.0F, 1.0F);
            p.playSound(p.getLocation(), Sound.PISTON_RETRACT, 10.0F, 1.0F);
            p.setGameMode(GameMode.SURVIVAL);
            p.setAllowFlight(false);
            p.setWalkSpeed(0.2f);
            p.setFireTicks(0);
            if (KitManager.getKit(p) != null) {
                Kit k = KitManager.getKit(p);
                if (k.getItems() != null) {
                    for (ItemStack items : k.getItems()) {
                        if (items != null) {
                            p.getInventory().addItem(items);
                        }
                    }
                }
            }
        }
        GameTimer.game();
    }

    @SuppressWarnings("deprecation")
    public static boolean check() {
        if(false) return false;

        if(Main.players.isEmpty()){
            for(Player l : Bukkit.getOnlinePlayers()){
                BungeeUtils.sendToServer(l.getName(), "lobby1");
            }
            new BukkitRunnable(){
                @Override
                public void run() {
                    if(Bukkit.getOnlinePlayers().size() == 0){
                        Bukkit.shutdown();
                    }
                }
            }.runTaskTimer(Main.getPlugin(), 0L, 20L);
            return true;
        }
        if (Main.players.size() != 1) return false;

        final Player p = Bukkit.getPlayer(Main.players.get(0));

        win(p);
        return true;
    }

    public static void win(Player p){
        Main.estado = GameState.WIN;
        GameTimer.gameTask.cancel();
        if (p == null || !p.isOnline()) {
            for(Player l : Bukkit.getOnlinePlayers()){
                BungeeUtils.sendToServer(l.getName(), "lobby1");
            }
            new BukkitRunnable(){
                @Override
                public void run() {
                    if(Bukkit.getOnlinePlayers().size() == 0){
                        Bukkit.shutdown();
                    }
                }
            }.runTaskTimer(Main.getPlugin(), 0L, 20L);
            return;
        }
        SQLStatus.addStatus(p.getUniqueId(), net.goodcraft.GameMode.SKYWARS, "wins", 1);
        SQLStatus.addCoins(p.getUniqueId(), 800);

        p.getInventory().clear();

        Location loc = p.getWorld().getSpawnLocation().clone().add(0.5, 0, 0.5);
        p.setAllowFlight(true);
        p.setFlying(true);
        p.teleport(loc.add(0, 3, 0));
        p.sendMessage(" ");
        Message.INFO.send(p, "§6[SkyWars]§e Parabéns! Você ganhou a partida!");
        Message.INFO.send(p, "§6[SkyWars]§e Tempo de jogo: " + Utils.secondsToString(Main.gameTime));
        String kit = "Nenhum";
        if (KitManager.getKit(p) != null) {
            kit = KitManager.getKit(p).toString();
        }
        Message.INFO.send(p, "§6[SkyWars]§e Seu kit: " + kit);
        Message.INFO.send(p, "§6[SkyWars]§e Suas kills: " + getKills(p));
        p.sendMessage(" ");

        Title.INFO.broadcast("SkyWars", p.getName() + " venceu!");

        p.getWorld().playSound(p.getLocation(), Sound.NOTE_PIANO, 1F, 1F);

        final boolean[] verify = new boolean[]{false};

        new BukkitRunnable() {
            public void run() {
                if(verify[0]){
                    cancel();
                    return;
                }

                if (p.isOnline()) {
                    Utils.firework(p.getLocation(), Color.AQUA);
                } else {
                    for (Player other : Bukkit.getOnlinePlayers()) {
                        BungeeUtils.sendToServer(other.getName(), "lobby1");
                    }
                    verify[0] = true;
                    cancel();
                    return;
                }
            }
        }.runTaskTimer(Main.getPlugin(), 0, 2 * 20L);

        new BukkitRunnable() {
            public void run() {
                for (Player other : Bukkit.getOnlinePlayers()) {
                    BungeeUtils.sendToServer(other.getName(), "lobby1");
                }
            }
        }.runTaskLater(Main.getPlugin(), 20 * 20L);

        new BukkitRunnable(){
            @Override
            public void run() {
                if(verify[0]){
                    if(Bukkit.getOnlinePlayers().size() == 0){
                        Bukkit.shutdown();
                    }
                }
            }
        }.runTaskTimer(Main.getPlugin(), 20L, 20L);
    }

    public static void addKill(Player p) {
        if (!kills.containsKey(p)) {
            kills.put(p.getUniqueId(), 1);
        } else {
            kills.put(p.getUniqueId(), getKills(p) + 1);
        }
        SQLStatus.addStatus(p.getUniqueId(), net.goodcraft.GameMode.SKYWARS, "kills", 1);
    }

    public static int getKills(Player p) {
        if (!kills.containsKey(p)) {
            kills.put(p.getUniqueId(), 0);
            return 0;
        }
        return kills.get(p.getUniqueId());
    }

    public static void messagePlayers(String msg){
        for(UUID id : Main.players){
            Player p = Bukkit.getPlayer(id);
            if(p == null) continue;
            p.sendMessage(msg);
        }
    }

    public static void teleport(){
        FileConfiguration c = Main.getPlugin().getConfig();
        Main.getPlugin().reloadConfig();
        int quantity = Main.maxPlayers;
        String prefix = "SPAWN_LOCATIONS.";
        for(int i = 0; i < quantity; i++){
            if(Main.players.size() - 1 < i) break;
            Player p = Bukkit.getPlayer(Main.players.get(i));
            String w = c.getString(prefix + i + ".w");

            World world = Bukkit.getWorld(w);
            if(world == null) break;
            double x = c.getDouble(prefix + i + ".x");
            double y = c.getDouble(prefix + i + ".y");
            double z = c.getDouble(prefix + i + ".z");
            float yaw = (float) c.getDouble(prefix + i + ".yaw");
            float pitch = (float) c.getDouble(prefix + i + ".pitch");
            Location l = new Location(world, x, y, z, yaw, pitch);
            p.teleport(l);
        }
    }
}
