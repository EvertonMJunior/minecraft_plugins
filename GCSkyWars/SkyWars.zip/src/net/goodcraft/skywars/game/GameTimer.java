package net.goodcraft.skywars.game;

import net.goodcraft.api.ActionBar;
import net.goodcraft.api.Message;
import net.goodcraft.api.Title;
import net.goodcraft.api.Utils;
import net.goodcraft.skywars.Main;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class GameTimer {
    public static BukkitTask preGameTask;
    public static BukkitTask gameTask;

    public static void preGame(){
        preGameTask = new BukkitRunnable(){
            @Override
            public void run() {
                int toStart = Main.toStart;
                if(Main.estado == null) Main.estado = GameState.PREGAME;
                if(Main.estado != GameState.PREGAME){
                    preGameTask = null;
                    cancel();
                    return;
                }
                if(Main.players.size() < Main.minPlayers){
                    int faltam = Main.minPlayers - Main.players.size();
                    ActionBar.INFO.broadcast("Mínimo de " + Main.minPlayers + " jogador" + (faltam != 1 ? "es" : "") + ". Falta" + (faltam != 1 ? "m " : " ") + faltam + " jogador" + (faltam != 1 ? "es" : "") + ".");
                    return;
                }
                if(Main.players.size() >= Main.maxPlayers && toStart >= 40){
                    Main.toStart = 29;
                    broadcastStarting(30);
                    playSound(Sound.CLICK);
                } else if((toStart % 15 == 0 && toStart > 15)){
                    broadcastStarting(toStart);
                } else if(toStart == 15 || toStart <= 10 && toStart > 0){
                    Title.INFO.broadcast("SkyWars", "A partida começa em " + Utils.secondsToSentence(toStart) + "!");
                    playSound(Sound.CLICK);
                } else if(toStart == 0){
                    GameManager.start();
                }
                ActionBar.INFO.broadcast("Começa em: " + Utils.secondsToString(toStart));

                Main.usingWorld.setTime(0);
                Main.usingWorld.setStorm(false);
                Main.usingWorld.setThundering(false);
                Main.toStart--;
            }
        }.runTaskTimer(Main.getPlugin(), 20L, 20L);
    }

    private static void broadcastStarting(int seconds){
        Message.INFO.broadcast("§6[SkyWars]§e A partida inicia em " + Utils.secondsToSentence(seconds) + "!");
    }

    private static void playSound(Sound s) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), s, 1.0F, 1.0F);
        }
    }

    public static void game(){
        gameTask = new BukkitRunnable(){
            @Override
            public void run() {
                int time = Main.gameTime;
                if(GameManager.check()){
                    cancel();
                    return;
                }

                if(time == 10 * 60){
                    Title.INFO.broadcast("SkyWars", "A partida excedeu 10 minutos.");
                    new BukkitRunnable(){
                        @Override
                        public void run() {
                            Map<UUID, Integer> kills = new HashMap<>();
                            for(UUID id : Main.players){
                                Player p = Bukkit.getPlayer(id);
                                if(p == null) continue;
                                kills.put(p.getUniqueId(), GameManager.getKills(p));
                            }

                            Map.Entry<UUID, Integer> topKiller = Collections.min(kills.entrySet(),
                                    new Comparator<Map.Entry<UUID, Integer>>() {
                                @Override
                                public int compare(Map.Entry<UUID, Integer> o1, Map.Entry<UUID, Integer> o2) {
                                    return o1.getValue().compareTo(o2.getValue());
                                }
                            });

                            final Player winner = Bukkit.getPlayer(topKiller.getKey());
                            Title.INFO.broadcast("SkyWars", "E o vencedor é: §k" + winner.getName());
                            new BukkitRunnable(){
                                @Override
                                public void run() {
                                    GameManager.win(winner);
                                    Title.INFO.broadcast("SkyWars", "E o vencedor é: " + winner.getName() + "!");
                                    for(UUID id : Main.players){
                                        if(id.equals(winner.getUniqueId())) continue;
                                        Player pl = Bukkit.getPlayer(id);
                                        if(pl == null) continue;
                                        pl.setHealth(0D);
                                    }
                                }
                            }.runTaskLater(Main.getPlugin(), 59L);
                        }
                    }.runTaskLater(Main.getPlugin(), 59L);
                    cancel();
                    return;
                }

                if((time < 10 && time % 5 == 0) && time != 10){
                    if(Main.estado != GameState.INVENCIBILITY) Main.estado = GameState.INVENCIBILITY;
                    Message.INFO.broadcast("§6[SkyWars]§e A invencibilidade acaba em " + Utils.secondsToSentence(10 - time) + "!");
                }
                if(time == 10){
                    Main.estado = GameState.STARTED;
                    Title.INFO.broadcast("SkyWars", "A invencibilidade acabou!");
                    playSound(Sound.WITHER_DEATH);

                }
                if(Main.estado == GameState.INVENCIBILITY){
                    ActionBar.INFO.broadcast("A invencibilidade acaba em: " + Utils.secondsToString(10 - time));
                }
                if(time >= 9 * 60){
                    ActionBar.INFO.broadcast("A partida acaba em: " + Utils.secondsToString((10 * 60) - time));
                }
                Main.gameTime++;

                Main.usingWorld.setTime(0);
                Main.usingWorld.setStorm(false);
                Main.usingWorld.setThundering(false);
            }
        }.runTaskTimer(Main.getPlugin(), 20L, 20L);
    }
}
