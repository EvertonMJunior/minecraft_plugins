package net.goodcraft.skywars;

import com.sk89q.worldedit.EditSession;
import net.goodcraft.api.ClassGetter;
import net.goodcraft.api.Message;
import net.goodcraft.api.Schematic;
import net.goodcraft.api.Utils;
import net.goodcraft.eventos.HologramKillEvent;
import net.goodcraft.skywars.eventos.*;
import net.goodcraft.skywars.game.GameState;
import net.goodcraft.skywars.game.GameTimer;
import net.goodcraft.skywars.game.SpectatorManager;
import net.goodcraft.skywars.kits.FreeKits;
import net.goodcraft.skywars.kits.Kit;
import net.goodcraft.skywars.kits.KitSelector;
import net.goodcraft.skywars.kits.ShopManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.UUID;
import java.util.logging.Level;
import java.util.stream.Collectors;


public class Main extends JavaPlugin{
    private static Plugin plugin;
    private static Scoreboard sb;

    public static GameState estado = null;
    public static World usingWorld;
    public static FreeKits freeKits;
    public static EditSession editSession;

    public static Boolean toggleKits = true;

    public static ArrayList<UUID> players = new ArrayList<>();
    public static ArrayList<Kit> notToggled = new ArrayList<>();

    public static int toStart = 300;
    public static int gameTime = 0;
    public static int minPlayers;
    public static int maxPlayers;
    public static int lobbyY;
    
    public static Plugin getPlugin() {
        return plugin;
    }
    
    public static Scoreboard getScoreboard() {
        return sb;
    }

    @Override
    public void onLoad() {
        Bukkit.getServer().unloadWorld(usingWorld, false);
        deleteDir(new File("world"));
    }
    
    @Override
    public void onEnable() {
        getLogger().log(Level.INFO, "Enabled {0} v{1}", new Object[]{this.getName(), this.getDescription().getVersion()});
        setup();

        super.onEnable();
    }

    @Override
    public void onDisable() {
        getLogger().log(Level.INFO, "Disabled {0} v{1}", new Object[]{this.getName(), this.getDescription().getVersion()});
        disable();

        super.onDisable();
    }

    private void setup() {
        plugin = this;
        sb = new Scoreboard();
        freeKits = new FreeKits();

        usingWorld = Bukkit.getWorld("world");

        usingWorld.getEntities().stream().filter(en -> en instanceof Villager).forEach(Entity::remove);
        for(org.bukkit.entity.Item i : usingWorld.getEntitiesByClass(org.bukkit.entity.Item.class)){
            HologramKillEvent.allowedItems.add(i);
            i.remove();
        }
        usingWorld.getEntities().stream().filter(en -> en instanceof ArmorStand).forEach(Entity::remove);

        usingWorld.setSpawnLocation(0,  + 3, 0);

        Utils.registerCommands(getFile());

        maxPlayers = Integer.valueOf(getConfig().getString("MAX_PLAYERS"));
        minPlayers = maxPlayers / 3;
        lobbyY = Integer.valueOf(getConfig().getString("WAITING-LOBBY_Y"));

        SpectatorManager.inv = Bukkit.createInventory(null, ((((Main.maxPlayers / 9) +
                ((Main.maxPlayers % 9 == 0) ? 0 : 1)) * 9)), "Jogadores");

        registerListeners();
        registerKits("net.goodcraft.skywars.kits.habilidades");

        Collections.sort(Kit.kits, new Comparator<Object>() {
            public int compare(Object o1, Object o2) {
                Kit c1 = (Kit) o1;
                Kit c2 = (Kit) o2;
                return c1.toString().compareToIgnoreCase(c2.toString());
            }
        });

        Location lobbyEspera = new Location(usingWorld, usingWorld.getSpawnLocation().getX(), lobbyY, usingWorld.getSpawnLocation().getZ());
        Location mapa = new Location(usingWorld, usingWorld.getSpawnLocation().getX(), 70, usingWorld.getSpawnLocation().getZ());

        players.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getUniqueId).collect(Collectors.toList()));

        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, sb, 20L, 20L);
        new BukkitRunnable() {

            @Override
            public void run() {
                estado = GameState.PREGAME;
                GameTimer.preGame();
                editSession = Schematic.paste("lobbyespera", lobbyEspera);
                Schematic.paste("mapa", mapa);
                freeKits.retrieveAllData();
                Message.INFO.send(Bukkit.getConsoleSender(), "[SkyWars] Pronto para o jogo.");
                usingWorld.setAutoSave(false);
                Bukkit.setSpawnRadius(0);
            }
        }.runTaskLater(this, 20L);
    }

    private void disable() {
        plugin = null;
        sb = null;
        freeKits = null;
        usingWorld = null;
        editSession = null;
        maxPlayers = 0;
        minPlayers = 0;
        SpectatorManager.inv = null;
    }

    private void registerListeners() {
        registerListener(new SkywarsCmdEvent());
        registerListener(new KitSelector());
        registerListener(new DamageEvent());
        registerListener(new DeathEvent());
        registerListener(new DropItemEvent());
        registerListener(new GeneralEvents());
        registerListener(new JoinEvent());
        registerListener(new MotdEvent());
        registerListener(new QuitEvent());
        registerListener(new ShopManager());
        registerListener(new SpectatorManager());
    }

    private void registerKits(String packageName) {
        for (Class<?> kits : ClassGetter.getClassesForPackage(this, packageName)) {
            if (Kit.class.isAssignableFrom(kits)) {
                try {
                    kits.newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void registerListener(Listener l) {
        getServer().getPluginManager().registerEvents(l, this);
    }

    public static void deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                deleteDir(new File(dir, children[i]));
            }
        }
        dir.delete();
    }
}
