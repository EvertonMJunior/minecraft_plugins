package com.goodcraft.bungee.comandos;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.plugin.Command;

public class GeneralCmds {
    public class ServerCmd extends Command{

        public ServerCmd() {
            super("server", "bungeecord.command.default");
        }

        @Override
        public void execute(CommandSender commandSender, String[] strings) {

        }
    }
}
