package net.goodcraft.lobby.npcs;

import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;

public class NPCAPI {

    public static File file;
    public static FileConfiguration cfg;
    public static String[] types;
}
