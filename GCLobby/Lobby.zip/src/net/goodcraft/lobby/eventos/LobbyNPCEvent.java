package net.goodcraft.lobby.eventos;

import net.citizensnpcs.api.event.NPCRightClickEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class LobbyNPCEvent implements Listener {
    @EventHandler
    public void onNPCClick(NPCRightClickEvent e) {

    }
}
