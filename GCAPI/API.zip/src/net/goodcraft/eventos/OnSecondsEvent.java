package net.goodcraft.eventos;

import net.goodcraft.api.SecondsEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class OnSecondsEvent implements Listener {
    @EventHandler
    public void onSecondsEvent(SecondsEvent e) {

    }
}
