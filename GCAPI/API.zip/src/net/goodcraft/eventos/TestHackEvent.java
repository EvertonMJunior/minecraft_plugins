package net.goodcraft.eventos;

import org.bukkit.event.Listener;

public class TestHackEvent implements Listener {

}
