package net.goodcraft.api;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.NameTagVisibility;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Tag {

    public static Map<UUID, Tag> tags = new HashMap<>();
    private Player p;
    private Rank rank;

    public Tag(Player p, Rank rank) {
        this.p = p;
        this.rank = rank;
        Tag.tags.put(p.getUniqueId(), this);
    }

    public static Tag getByUUID(UUID id) {
        return tags.get(id);
    }

    public static void updateFor(Player p) {
        for (UUID id : tags.keySet()) {
            Player t = Bukkit.getPlayer(id);
            if (t == null) {
                continue;
            }
            Tag obj = tags.get(id);
            obj.update(p);
        }
    }

    public Rank getRank() {
        return this.rank;
    }

    public void setRank(Rank r) {
        this.rank = r;
    }

    public void update(Player toUpdate) {
        Rank r = getRank() == null ? Rank.NORMAL : getRank();

        String prefixo = r.getColor() + "[" + r.getAliases().get(0) + "] ";

        Scoreboard sb = toUpdate.getScoreboard();
        if (sb == null) return;

        String teamName = ("0" + r.ordinal()) + r.getAliases().get(0);

        Team tag = sb.getTeam(teamName) != null ?
                sb.getTeam(teamName) : sb.registerNewTeam(teamName);

        PlayerTagEvent event = new PlayerTagEvent(this, toUpdate, prefixo, tag);
        Bukkit.getPluginManager().callEvent(event);

        if (event.isCancelled()) {
            tag.unregister();
            return;
        }

        tag.setPrefix(event.getPrefix());

        tag.setDisplayName(r != Rank.NORMAL ? prefixo : "§7NORMAL");
        tag.setNameTagVisibility(NameTagVisibility.ALWAYS);

        tag.addEntry(p.getName());
    }

    public void updateForAll() {
        Bukkit.getOnlinePlayers().forEach(this::update);
    }
}
